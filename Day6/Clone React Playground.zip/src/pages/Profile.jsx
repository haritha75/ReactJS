import React from "react";
import {ChangeProfile} from '../components/ChangeProfile';
export const Profile = (props) => {
  return <div> PROFILE,user is : {props.userName}
  <ChangeProfile setUserName={props.setUserName}/>
  </div>;
};
