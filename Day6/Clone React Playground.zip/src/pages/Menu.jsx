import React from "react";

export const Menu = () => {
  return <h1> THIS IS THE MENU PAGE</h1>;
};
