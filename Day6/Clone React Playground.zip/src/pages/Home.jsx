import React from "react";

export const Home = (props) => {
  return <h1> THIS IS THE HOME PAGE and USER IS: {props.userName}</h1>;
};
