// router is used defined where your app we want access to react of dom staff
// routes defined all the route
import React from "react";
import "./style.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Home } from "./pages/Home";
import { Menu } from "./pages/Menu";
import { Contact } from "./pages/Contact";
import {Profile} from './pages/Profile'
import { Navbar } from "./Navbar";
import {useState} from 'react';

function App() {
  const [userName,setUserName] = useState("PedroTech");
  return (
    <div className="App">
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home userName={userName}/>} />
          <Route path="/profile" element={<Profile userName={userName} setUserName={setUserName}/>} />
          <Route path="/menu" element={<Menu />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="*" element={<h1> PAGE NOT FOUND</h1>} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
