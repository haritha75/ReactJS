import React from "react";
import {useState} from 'react';

export const  ChangeProfile= (props) => {
  const [newUSerName,setNewUserName] = useState("");
  return(
    <div> <input onChange={(event)=>{
      setNewUserName(event.target.value);
    }}/>
    <button onClick={()=>{
      props.setUserName(newUSerName);
    }}>Change Username</button> </div>
  )
};
